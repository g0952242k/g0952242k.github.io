
<!doctype html>
<html>
<head>
<title>Geolocation API: Technotip.com</title>
<meta charset="utf-8"/>
<link href="myStyle.css" rel="stylesheet"/>
<script src="jquery-1.10.1.min.js"></script>
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src="myScriptMap.js"></script>
</head>
<body>
<p id="map"></p>
<button>Stop</button>
</body>
</html>